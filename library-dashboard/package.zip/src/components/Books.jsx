import React, { useState } from "react";
import { books as mockBooks, authors as mockAuthors } from "../mockData";

function Books() {
  const [books, setBooks] = useState(mockBooks);
  const [authors] = useState(mockAuthors);
  const [newTitle, setNewTitle] = useState("");
  const [selectedAuthorIds, setSelectedAuthorIds] = useState([]);

  const addBook = () => {
    if (!newTitle.trim() || selectedAuthorIds.length === 0) {
      alert("Enter title and select at least one author");
      return;
    }

    const newBook = {
      id: Date.now(),
      title: newTitle,
      authorIds: selectedAuthorIds.map(id => parseInt(id)),
      available: true,
    };

    setBooks([...books, newBook]);
    setNewTitle("");
    setSelectedAuthorIds([]);
  };

  const deleteBook = (id) => {
    setBooks(books.filter(book => book.id !== id));
  };

  const getAuthorNames = (authorIds) => {
    return authorIds.map(id => authors.find(a => a.id === id)?.name).join(", ");
  };

  return (
    <div>
      <h2>Books List</h2>
      <ul>
        {books.map(book => (
          <li key={book.id} style={{ marginBottom: "10px" }}>
            <strong>{book.title}</strong><br />
            Authors: {getAuthorNames(book.authorIds)}<br />
            Availability: {book.available ? "✅ Available" : "❌ Issued"}<br />
            <button onClick={() => deleteBook(book.id)} style={{ marginTop: "5px" }}>Delete</button>
          </li>
        ))}
      </ul>

      <h3>Add New Book</h3>
      <input
        type="text"
        placeholder="Book Title"
        value={newTitle}
        onChange={(e) => setNewTitle(e.target.value)}
      /><br />
      
      <label>Select Authors:</label><br />
      <select
        multiple
        value={selectedAuthorIds}
        onChange={(e) => {
          const options = Array.from(e.target.selectedOptions);
          setSelectedAuthorIds(options.map(opt => opt.value));
        }}
        style={{ height: "100px", width: "200px" }}
      >
        {authors.map(author => (
          <option key={author.id} value={author.id}>
            {author.name}
          </option>
        ))}
      </select>
      <br />
      <button onClick={addBook} style={{ marginTop: "10px" }}>Add Book</button>
    </div>
  );
}

export default Books;
