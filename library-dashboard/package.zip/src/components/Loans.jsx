// src/components/Loans.jsx
import React, { useState } from "react";
import { books as mockBooks, borrowers as mockBorrowers, loans as mockLoans } from "../mockData";

function Loans() {
  const [books, setBooks] = useState(mockBooks);
  const [borrowers] = useState(mockBorrowers);
  const [loans, setLoans] = useState(mockLoans);

  const [selectedBookId, setSelectedBookId] = useState("");
  const [selectedBorrowerId, setSelectedBorrowerId] = useState("");

  const borrowBook = () => {
    if (!selectedBookId || !selectedBorrowerId) return alert("Select both book and borrower");
    const book = books.find(b => b.id === parseInt(selectedBookId));
    if (!book.available) return alert("Book is already issued");

    const newLoan = {
      id: Date.now(),
      bookId: parseInt(selectedBookId),
      borrowerId: parseInt(selectedBorrowerId),
      issueDate: new Date().toISOString().split("T")[0],
      returnDate: null,
    };

    setLoans([...loans, newLoan]);
    setBooks(books.map(b => b.id === book.id ? { ...b, available: false } : b));
    setSelectedBookId("");
    setSelectedBorrowerId("");
  };

  const returnBook = (loanId) => {
    setLoans(loans.map(loan =>
      loan.id === loanId ? { ...loan, returnDate: new Date().toISOString().split("T")[0] } : loan
    ));
    const loan = loans.find(l => l.id === loanId);
    setBooks(books.map(b => b.id === loan.bookId ? { ...b, available: true } : b));
  };

  const getBorrowerName = (id) => borrowers.find(b => b.id === id)?.name || "Unknown";
  const getBookTitle = (id) => books.find(b => b.id === id)?.title || "Unknown";

  const isOverdue = (issueDate, returnDate) => {
    if (returnDate) return false;
    const issue = new Date(issueDate);
    const today = new Date();
    const diffDays = Math.ceil((today - issue) / (1000 * 60 * 60 * 24));
    return diffDays > 14;
  };

  return (
    <div>
      <h2>Loan Management</h2>

      <h3>Borrow a Book</h3>
      <select value={selectedBorrowerId} onChange={(e) => setSelectedBorrowerId(e.target.value)}>
        <option value="">Select Borrower</option>
        {borrowers.map(b => (
          <option key={b.id} value={b.id}>{b.name}</option>
        ))}
      </select>

      <select value={selectedBookId} onChange={(e) => setSelectedBookId(e.target.value)}>
        <option value="">Select Book</option>
        {books.filter(b => b.available).map(b => (
          <option key={b.id} value={b.id}>{b.title}</option>
        ))}
      </select>

      <button onClick={borrowBook}>Borrow Book</button>

      <h3>Issued Books</h3>
      <ul>
        {loans.map(loan => {
          const overdue = isOverdue(loan.issueDate, loan.returnDate);
          return (
            <li
              key={loan.id}
              style={{ marginBottom: "10px", color: overdue ? "red" : "black" }}
            >
              <strong>{getBookTitle(loan.bookId)}</strong> borrowed by <strong>{getBorrowerName(loan.borrowerId)}</strong><br />
              Issued: {loan.issueDate} <br />
              Returned: {loan.returnDate || "Not yet"} <br />
              {overdue && !loan.returnDate && <strong>🚨 Overdue</strong>}<br />
              {!loan.returnDate && <button onClick={() => returnBook(loan.id)}>Return</button>}
            </li>
          );
        })}
      </ul>
    </div>
  );
}

export default Loans;
