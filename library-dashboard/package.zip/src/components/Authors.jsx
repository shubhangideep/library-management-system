// src/components/Authors.jsx
import React, { useState } from "react";
import { authors as mockAuthors, books as mockBooks } from "../mockData";

function Authors() {
  const [authors, setAuthors] = useState(mockAuthors);
  const [books] = useState(mockBooks);

  const [newAuthorName, setNewAuthorName] = useState("");
  const [editingId, setEditingId] = useState(null);
  const [editName, setEditName] = useState("");

  const getBookCount = (authorId) => {
    return books.filter(book => book.authorIds.includes(authorId)).length;
  };

  const addAuthor = () => {
    if (!newAuthorName.trim()) return alert("Enter author name");
    const newAuthor = {
      id: Date.now(),
      name: newAuthorName,
    };
    setAuthors([...authors, newAuthor]);
    setNewAuthorName("");
  };

  const startEdit = (author) => {
    setEditingId(author.id);
    setEditName(author.name);
  };

  const saveEdit = () => {
    setAuthors(authors.map(a => a.id === editingId ? { ...a, name: editName } : a));
    setEditingId(null);
    setEditName("");
  };

  const deleteAuthor = (id) => {
    setAuthors(authors.filter(a => a.id !== id));
  };

  return (
    <div>
      <h2>Authors List</h2>
      <ul>
        {authors.map(author => (
          <li key={author.id} style={{ marginBottom: "10px" }}>
            {editingId === author.id ? (
              <>
                <input
                  value={editName}
                  onChange={(e) => setEditName(e.target.value)}
                />
                <button onClick={saveEdit}>Save</button>
              </>
            ) : (
              <>
                <strong>{author.name}</strong> — {getBookCount(author.id)} book(s)
                <br />
                <button onClick={() => startEdit(author)}>Edit</button>
              </>
            )}
            <button onClick={() => deleteAuthor(author.id)} style={{ marginLeft: "10px" }}>Delete</button>
          </li>
        ))}
      </ul>

      <h3>Add New Author</h3>
      <input
        type="text"
        placeholder="Author Name"
        value={newAuthorName}
        onChange={(e) => setNewAuthorName(e.target.value)}
      />
      <button onClick={addAuthor}>Add Author</button>
    </div>
  );
}

export default Authors;
