// src/components/Borrowers.jsx
import React, { useState } from "react";
import { borrowers as mockBorrowers, books as mockBooks, loans as mockLoans } from "../mockData";

function Borrowers() {
  const [borrowers, setBorrowers] = useState(mockBorrowers);
  const [books] = useState(mockBooks);
  const [loans] = useState(mockLoans);

  const [newBorrowerName, setNewBorrowerName] = useState("");
  const [editingId, setEditingId] = useState(null);
  const [editName, setEditName] = useState("");

  const addBorrower = () => {
    if (!newBorrowerName.trim()) return alert("Enter borrower name");
    const newBorrower = {
      id: Date.now(),
      name: newBorrowerName,
    };
    setBorrowers([...borrowers, newBorrower]);
    setNewBorrowerName("");
  };

  const startEdit = (borrower) => {
    setEditingId(borrower.id);
    setEditName(borrower.name);
  };

  const saveEdit = () => {
    setBorrowers(borrowers.map(b => b.id === editingId ? { ...b, name: editName } : b));
    setEditingId(null);
    setEditName("");
  };

  const deleteBorrower = (id) => {
    setBorrowers(borrowers.filter(b => b.id !== id));
  };

  const getBorrowedBooks = (borrowerId) => {
    const currentLoans = loans.filter(loan => loan.borrowerId === borrowerId && !loan.returnDate);
    return currentLoans.map(loan => books.find(book => book.id === loan.bookId)?.title).join(", ") || "None";
  };

  return (
    <div>
      <h2>Borrowers</h2>
      <ul>
        {borrowers.map(borrower => (
          <li key={borrower.id} style={{ marginBottom: "10px" }}>
            {editingId === borrower.id ? (
              <>
                <input
                  value={editName}
                  onChange={(e) => setEditName(e.target.value)}
                />
                <button onClick={saveEdit}>Save</button>
              </>
            ) : (
              <>
                <strong>{borrower.name}</strong><br />
                Borrowed Books: {getBorrowedBooks(borrower.id)}<br />
                <button onClick={() => startEdit(borrower)}>Edit</button>
              </>
            )}
            <button onClick={() => deleteBorrower(borrower.id)} style={{ marginLeft: "10px" }}>Delete</button>
          </li>
        ))}
      </ul>

      <h3>Add New Borrower</h3>
      <input
        type="text"
        placeholder="Borrower Name"
        value={newBorrowerName}
        onChange={(e) => setNewBorrowerName(e.target.value)}
      />
      <button onClick={addBorrower}>Add Borrower</button>
    </div>
  );
}

export default Borrowers;
