// src/App.jsx
import React from "react";
import Dashboard from "./components/Dashboard";

function App() {
  return (
    <div style={{ padding: "20px", fontFamily: "sans-serif" }}>
      <h1>📚 Library Management Dashboard</h1>
      <Dashboard />
    </div>
  );
}

export default App;
